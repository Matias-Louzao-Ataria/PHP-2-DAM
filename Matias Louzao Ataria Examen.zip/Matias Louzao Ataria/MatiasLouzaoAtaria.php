<?php

define("TAMANHO",5);

abstract class Contacto{
    private $nombre = "";
    private $telefono = "";
    private $direccion = "";

    public function setNombre($nombre){
        if(strlen($nombre) > 0 || $nombre != null){
            $this -> nombre = $nombre;
        }else{
            echo "Nombre no válido";
            echo "<br>";
        }
    }

    public function getNombre(){
        return $this -> nombre;
    }

    public function setTelefono($telefono){
        $cont = 0;
        for($i = 0;$i < strlen($telefono);$i++){
            if($telefono[$i] >= 0 && $telefono[$i] <= 9){
                $cont++;
            }
        }
        if($cont == 9 || $cont == 13){
            $this -> telefono = $telefono;
        }else{
            echo "Teléfono no válido!";
            echo "<br>";
        }
    }

    public function getTelefono(){
        return $this -> telefono;
    }

    public function setDireccion($direccion){
        if(strlen($direccion) > 0 || $direccion != null){
            $this -> direccion = $direccion;
        }else{
            echo "Dirección no válida!";
            echo "<br>";
        }
    }

    public function getDireccion(){
        return $this -> direccion;
    }

    public function __construct($nombre,$telefono,$direccion){
        $this -> setNombre($nombre);
        $this -> setTelefono($telefono);
        $this -> setDireccion($direccion);
    }
}

class Particular extends Contacto{
    public function __construct($nombre,$telefono,$direccion){
        parent::__construct($nombre,$telefono,$direccion);        
    }
}

class Empresa extends Contacto{
    private $cif  = "";

    public function setCif($cif){
        $letra = false;
        $guion = false;
        $cont = 0;
        for($i = 0;$i < strlen($cif);$i++){
            if((($cif[$i] >= 'a' && $cif[$i] <= 'z') || ($cif[$i] >= 'A' && $cif[$i] <= 'Z')) && $i == 0){
                $letra = true;
            }
            if(($cif[$i] == '-') && $i == 1){
                $guion = true;
            }
            if(($cif[$i] >= 0 && $cif[$i] <= 9)&& ($i != 0 && $i != 1)){
                $cont++;
            }
        }
        if($letra && $guion && $cont == 8){
            $this -> cif = $cif;
        }else{
            echo "CIF no válido!";
            echo "<br>";
        }
    }

    public function getCif(){
        return $this -> cif;
    }

    public function __construct($nombre,$telefono,$direccion,$cif){
        parent::__construct($nombre,$telefono,$direccion);
        $this -> setCif($cif);
    }
}

class Agenda{
    private $contactos = array();

    public function existeContacto($contacto){
        for($i = 0;$i < count($this -> contactos);$i++){
            $contactoActual = $this -> contactos[$i];
            if(strcasecmp($contactoActual -> getNombre(),$contacto -> getNombre()) === 0){
                if(strcasecmp($contactoActual -> getTelefono(),$contacto -> getTelefono()) === 0){
                    return $i;
                }
            }
        }
        return false;
    }

    public function anhadirContacto($contacto){
        if(count($this -> contactos) < TAMANHO){
            if(strlen($contacto -> getTelefono()) > 0){
                if(strcmp(get_class($contacto),"Particular") == 0){
                    if($this -> existeContacto($contacto) === false){
                        array_push($this -> contactos,$contacto);
                        echo "Contacto añadido!";
                        echo "<br>";
                    }else{
                        echo "Ya existe el contacto y no se añadirá a la agenda!";
                        echo "<br>";
                    }
                }else{
                    if(strlen($contacto -> getCif()) > 0){
                        if($this -> existeContacto($contacto) === false){
                            array_push($this -> contactos,$contacto);
                            echo "Contacto añadido!";
                            echo "<br>";
                    }else{  
                            echo "Ya existe el contacto y no se añadirá a la agenda!";
                            echo "<br>";
                        }
                    }
                }
            }else{
                echo "No se pudo añadir el contacto!";
                echo "<br>";
            }
        }else{
            echo "Agenda llena!";
            echo "<br>";
        }
        
    }

    public function listaContactos(){
        if(count($this -> contactos) > 0){
            for($i = 0;$i < count($this -> contactos);$i++){
                $contactoActual = $this -> contactos[$i];
                echo "Nombre: ".$contactoActual -> getNombre();
                echo "<br>";
                echo "Teléfono: ".$contactoActual -> getTelefono();
                echo "<br>";
                echo "Dirección: ".$contactoActual -> getDireccion();
                echo "<br>";
                if(strcmp(get_class($contactoActual),"Particular") != 0){
                    echo "CIF: ".$contactoActual -> getCif();
                    echo "<br>";
                }
            }
        }else{
            echo "Lista vacia!";
            echo "<br>";
        }
    }

    public function listaEmpresas(){
        if(count($this -> contactos) > 0){
            for($i = 0;$i < count($this -> contactos);$i++){
                $contactoActual = $this -> contactos[$i];
                if(strcmp(get_class($contactoActual),"Particular") != 0){
                    echo "Nombre: ".$contactoActual -> getNombre();
                    echo "<br>";
                    echo "Teléfono: ".$contactoActual -> getTelefono();
                    echo "<br>";
                    echo "Dirección: ".$contactoActual -> getDireccion();
                    echo "<br>";
                    echo "CIF: ".$contactoActual -> getCif();
                    echo "<br>";
                }
            }
        }else{
            echo "Lista vacia!";
            echo "<br>";
        }
    }
    
    public function buscarContacto($nombre){
        for($i = 0;$i < count($this -> contactos);$i++){
            $contactoActual = $this -> contactos[$i];
            if(strcasecmp($contactoActual -> getNombre(),$nombre) == 0){
                echo "Nombre: ".$contactoActual -> getNombre();
                echo "<br>";
                echo "Teléfono: ".$contactoActual -> getTelefono();
                echo "<br>";
            }
        }
    }

    public function eliminaContacto($contacto){
        $pos = $this -> existeContacto($contacto);
        if($pos !== false){
            array_splice($this -> contactos,$pos,1);
            echo "Contacto eliminado";
            echo "<br>";
        }else{
            echo "No se encontró en contacto!";
            echo "<br>";
        }
    }

    public function huecosLibres(){
        return TAMANHO - count($this -> contactos);
    }

    public function __construct(){

    }
}

$p = new Particular("A",123456789,"dirección");
$p2 = new Particular("C",1234567891111,"dirección");
$p3 = new Particular("C",1334567891111,"dirección");
$e = new Empresa("E",123456777,"windir","A-44444444");
$e2 = new Empresa("E",123456777,"windir","A-4444444");
$a = new Agenda();
echo "<br>";
echo "<br>";
echo "<br>";
echo "Huecos libres:".$a -> huecosLibres();
echo "<br>";
echo "<br>";
echo "<br>";
$a -> anhadirContacto($p);
$a -> anhadirContacto($p2);
$a -> anhadirContacto($p3);
$a -> anhadirContacto($e);
$a -> anhadirContacto($e2);
echo "Huecos libres:".$a -> huecosLibres();
echo "<br>";
echo "<br>";
echo "<br>";
$a -> listaContactos();
echo "<br>";
echo "<br>";
echo "<br>";
$a -> listaEmpresas();
echo "<br>";
echo "<br>";
echo "<br>";
$a -> buscarContacto($p2 -> getNombre());
echo "<br>";
echo "<br>";
echo "<br>";
$a -> listaContactos();
echo "<br>";
echo "<br>";
echo "<br>";
$a -> eliminaContacto($p2);
echo "Huecos libres:".$a -> huecosLibres();
echo "<br>";
echo "<br>";
echo "<br>";
$a -> listaContactos();
?>